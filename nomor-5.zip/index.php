<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gear Trakr – Lost and Found Tags & Stickers</title>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;600;700&family=Barlow:wght@300;400;500&display=swap" rel="stylesheet">
<style>
  :root {
    --primary: #0A6EBD;
    --primary-dark: #084F8A;
    --accent: #F4A614;
    --dark: #0D1B2A;
    --mid: #3A4D5C;
    --light: #F0F5FA;
    --white: #ffffff;
    --border: #D9E5EE;
    --text: #1C2B38;
    --muted: #6B7F8E;
  }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Barlow', sans-serif; color: var(--text); background: var(--white); }
  a { text-decoration: none; color: inherit; }
  img { display: block; max-width: 100%; }

  /* ===== ADMIN BAR (WordPress style) ===== */
  .wp-admin-bar {
    background: #1d2327;
    color: #c3c4c7;
    font-size: 12px;
    height: 32px;
    display: flex;
    align-items: center;
    padding: 0 1rem;
    gap: 1.5rem;
    position: sticky;
    top: 0;
    z-index: 200;
  }
  .wp-admin-bar span { opacity: 0.7; cursor: pointer; }
  .wp-admin-bar span:hover { opacity: 1; color: #fff; }
  .wp-admin-bar .wp-logo { color: #c3c4c7; font-weight: 600; }

  /* ===== HEADER ===== */
  header {
    background: var(--dark);
    position: sticky;
    top: 32px;
    z-index: 100;
  }
  .header-inner {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 2rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 72px;
  }
  .site-logo {
    font-family: 'Barlow Condensed', sans-serif;
    font-size: 1.8rem;
    font-weight: 700;
    color: var(--white);
    letter-spacing: 0.04em;
  }
  .site-logo span { color: var(--accent); }
  .main-nav { display: flex; align-items: center; gap: 0; }
  .main-nav a {
    font-size: 0.85rem;
    font-weight: 500;
    color: rgba(255,255,255,0.8);
    text-transform: uppercase;
    letter-spacing: 0.07em;
    padding: 0 1.1rem;
    height: 72px;
    display: flex;
    align-items: center;
    border-bottom: 3px solid transparent;
    transition: all 0.2s;
  }
  .main-nav a:hover, .main-nav a.active {
    color: var(--white);
    border-bottom-color: var(--accent);
  }
  .header-cta {
    background: var(--accent);
    color: var(--dark);
    font-family: 'Barlow Condensed', sans-serif;
    font-size: 0.9rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    padding: 0.6rem 1.4rem;
    border-radius: 3px;
    transition: background 0.2s;
  }
  .header-cta:hover { background: #e09800; }

  /* ===== HERO ===== */
  .hero {
    background: linear-gradient(135deg, var(--dark) 0%, #1a3a5c 60%, #0A6EBD 100%);
    min-height: 560px;
    display: flex;
    align-items: center;
    position: relative;
    overflow: hidden;
  }
  .hero::before {
    content: '';
    position: absolute;
    inset: 0;
    background-image: radial-gradient(circle at 70% 50%, rgba(10,110,189,0.3) 0%, transparent 60%);
  }
  .hero-grid {
    max-width: 1200px;
    margin: 0 auto;
    padding: 5rem 2rem;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 4rem;
    align-items: center;
    position: relative;
    z-index: 1;
  }
  .hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    background: rgba(244,166,20,0.15);
    border: 1px solid rgba(244,166,20,0.4);
    color: var(--accent);
    font-size: 0.72rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.12em;
    padding: 0.35rem 0.9rem;
    border-radius: 2rem;
    margin-bottom: 1.5rem;
  }
  .hero-title {
    font-family: 'Barlow Condensed', sans-serif;
    font-size: 3.8rem;
    font-weight: 700;
    color: var(--white);
    line-height: 1.05;
    margin-bottom: 1.25rem;
    letter-spacing: 0.01em;
  }
  .hero-title .highlight { color: var(--accent); }
  .hero-desc {
    font-size: 1.05rem;
    color: rgba(255,255,255,0.7);
    line-height: 1.7;
    margin-bottom: 2rem;
    font-weight: 300;
  }
  .hero-btns { display: flex; gap: 1rem; flex-wrap: wrap; }
  .btn-yellow {
    background: var(--accent);
    color: var(--dark);
    font-family: 'Barlow Condensed', sans-serif;
    font-weight: 700;
    font-size: 1rem;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    padding: 0.85rem 2rem;
    border-radius: 3px;
    transition: background 0.2s;
    display: inline-block;
  }
  .btn-yellow:hover { background: #e09800; }
  .btn-ghost {
    background: transparent;
    color: var(--white);
    font-family: 'Barlow Condensed', sans-serif;
    font-weight: 600;
    font-size: 1rem;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    padding: 0.85rem 2rem;
    border: 1px solid rgba(255,255,255,0.35);
    border-radius: 3px;
    transition: all 0.2s;
    display: inline-block;
  }
  .btn-ghost:hover { border-color: rgba(255,255,255,0.8); }

  /* Hero visual */
  .hero-visual {
    display: flex;
    flex-direction: column;
    gap: 1rem;
    align-items: center;
  }
  .tag-card {
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.15);
    border-radius: 12px;
    padding: 1.5rem 2rem;
    width: 100%;
    max-width: 360px;
    backdrop-filter: blur(10px);
  }
  .tag-card-label { font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.12em; color: var(--accent); margin-bottom: 0.8rem; }
  .tag-card-name { font-family: 'Barlow Condensed', sans-serif; font-size: 1.3rem; font-weight: 600; color: #fff; margin-bottom: 0.3rem; }
  .tag-card-info { font-size: 0.85rem; color: rgba(255,255,255,0.6); }
  .tag-scan-btn {
    display: flex;
    align-items: center;
    gap: 0.7rem;
    background: var(--primary);
    border-radius: 8px;
    padding: 0.8rem 1.5rem;
    width: 100%;
    max-width: 360px;
    color: white;
    font-size: 0.9rem;
    font-weight: 500;
    cursor: pointer;
    transition: background 0.2s;
  }
  .tag-scan-btn:hover { background: var(--primary-dark); }
  .scan-dot { width: 10px; height: 10px; background: #4dffb4; border-radius: 50%; animation: pulse 1.5s infinite; }
  @keyframes pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:0.5;transform:scale(1.3)} }

  /* ===== TRUST BAR ===== */
  .trust-bar { background: var(--primary); padding: 1rem 2rem; }
  .trust-inner { max-width: 1200px; margin: 0 auto; display: flex; justify-content: space-around; align-items: center; flex-wrap: wrap; gap: 1rem; }
  .trust-item { display: flex; align-items: center; gap: 0.6rem; color: rgba(255,255,255,0.9); font-size: 0.85rem; font-weight: 500; }
  .trust-icon { width: 20px; height: 20px; flex-shrink: 0; }

  /* ===== SECTIONS ===== */
  .section { padding: 5rem 2rem; }
  .section-inner { max-width: 1200px; margin: 0 auto; }
  .section-header { text-align: center; margin-bottom: 3.5rem; }
  .section-label { font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.15em; color: var(--primary); font-weight: 600; margin-bottom: 0.75rem; }
  .section-title { font-family: 'Barlow Condensed', sans-serif; font-size: 2.4rem; font-weight: 700; color: var(--dark); }
  .section-desc { font-size: 1rem; color: var(--muted); margin-top: 0.75rem; max-width: 560px; margin-left: auto; margin-right: auto; line-height: 1.65; }

  /* ===== HOW IT WORKS ===== */
  .steps-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 2rem; }
  .step-card {
    background: var(--light);
    border-radius: 10px;
    padding: 2.5rem 2rem;
    position: relative;
    border: 1px solid var(--border);
    transition: box-shadow 0.25s, transform 0.25s;
  }
  .step-card:hover { box-shadow: 0 8px 32px rgba(10,110,189,0.12); transform: translateY(-4px); }
  .step-num {
    font-family: 'Barlow Condensed', sans-serif;
    font-size: 4rem;
    font-weight: 700;
    color: var(--primary);
    opacity: 0.15;
    line-height: 1;
    margin-bottom: 1rem;
  }
  .step-icon { margin-bottom: 1rem; }
  .step-title { font-family: 'Barlow Condensed', sans-serif; font-size: 1.3rem; font-weight: 700; color: var(--dark); margin-bottom: 0.6rem; }
  .step-desc { font-size: 0.9rem; color: var(--muted); line-height: 1.65; }
  .step-link { display: inline-flex; align-items: center; gap: 0.4rem; font-size: 0.82rem; font-weight: 600; color: var(--primary); margin-top: 1rem; text-transform: uppercase; letter-spacing: 0.05em; }
  .step-link:hover { text-decoration: underline; }

  /* ===== PRODUCTS ===== */
  .bg-light { background: var(--light); }
  .products-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1.5rem; }
  .product-card {
    background: var(--white);
    border: 1px solid var(--border);
    border-radius: 10px;
    overflow: hidden;
    transition: box-shadow 0.25s;
  }
  .product-card:hover { box-shadow: 0 6px 24px rgba(0,0,0,0.1); }
  .product-img {
    aspect-ratio: 4/3;
    background: var(--light);
    display: flex;
    align-items: center;
    justify-content: center;
    border-bottom: 1px solid var(--border);
  }
  .product-body { padding: 1.25rem 1.5rem 1.5rem; }
  .product-cat { font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.12em; color: var(--primary); font-weight: 600; margin-bottom: 0.4rem; }
  .product-name { font-family: 'Barlow Condensed', sans-serif; font-size: 1.3rem; font-weight: 700; color: var(--dark); margin-bottom: 0.5rem; }
  .product-desc { font-size: 0.85rem; color: var(--muted); line-height: 1.6; margin-bottom: 1.2rem; }
  .product-price { font-family: 'Barlow Condensed', sans-serif; font-size: 1.5rem; font-weight: 700; color: var(--dark); }
  .product-price span { font-size: 0.85rem; color: var(--muted); font-weight: 400; }
  .btn-buy {
    display: block;
    text-align: center;
    background: var(--primary);
    color: var(--white);
    font-family: 'Barlow Condensed', sans-serif;
    font-weight: 700;
    font-size: 0.95rem;
    text-transform: uppercase;
    letter-spacing: 0.07em;
    padding: 0.7rem;
    border-radius: 5px;
    margin-top: 1rem;
    transition: background 0.2s;
  }
  .btn-buy:hover { background: var(--primary-dark); }

  /* ===== TUTORIAL SECTION ===== */
  .tutorial-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 4rem; align-items: center; }
  .tutorial-steps { display: flex; flex-direction: column; gap: 1.5rem; }
  .tut-step { display: flex; gap: 1.2rem; align-items: flex-start; }
  .tut-num {
    width: 36px; height: 36px;
    background: var(--primary);
    color: white;
    font-family: 'Barlow Condensed', sans-serif;
    font-size: 1rem;
    font-weight: 700;
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
  }
  .tut-content h4 { font-family: 'Barlow Condensed', sans-serif; font-size: 1.1rem; font-weight: 700; color: var(--dark); margin-bottom: 0.3rem; }
  .tut-content p { font-size: 0.87rem; color: var(--muted); line-height: 1.6; }
  .tutorial-visual {
    background: var(--dark);
    border-radius: 16px;
    padding: 2.5rem;
    color: white;
  }
  .phone-mock {
    background: #1a3a5c;
    border-radius: 12px;
    padding: 1.5rem;
    margin-bottom: 1.5rem;
    border: 1px solid rgba(255,255,255,0.1);
  }
  .phone-header { font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.1em; color: var(--accent); margin-bottom: 1rem; }
  .phone-field { background: rgba(255,255,255,0.08); border-radius: 6px; padding: 0.7rem 1rem; margin-bottom: 0.7rem; }
  .phone-field-label { font-size: 0.65rem; text-transform: uppercase; letter-spacing: 0.08em; color: rgba(255,255,255,0.4); margin-bottom: 0.2rem; }
  .phone-field-val { font-size: 0.9rem; color: rgba(255,255,255,0.9); }
  .phone-scan-area {
    background: rgba(10,110,189,0.3);
    border: 2px dashed rgba(10,110,189,0.6);
    border-radius: 8px;
    padding: 1.5rem;
    text-align: center;
    color: rgba(255,255,255,0.7);
    font-size: 0.85rem;
  }
  .tutorial-cta { text-align: center; }
  .tutorial-cta a {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    color: var(--accent);
    font-family: 'Barlow Condensed', sans-serif;
    font-size: 1rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    border-bottom: 2px solid var(--accent);
    padding-bottom: 3px;
  }

  /* ===== TESTIMONIALS ===== */
  .testimonials-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1.5rem; }
  .testi-card {
    background: var(--white);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 1.75rem;
  }
  .stars { color: var(--accent); font-size: 0.9rem; margin-bottom: 1rem; letter-spacing: 2px; }
  .testi-text { font-size: 0.9rem; color: var(--mid); line-height: 1.7; margin-bottom: 1.25rem; font-style: italic; }
  .testi-author { display: flex; align-items: center; gap: 0.75rem; }
  .testi-avatar {
    width: 38px; height: 38px;
    border-radius: 50%;
    background: var(--primary);
    color: white;
    font-family: 'Barlow Condensed', sans-serif;
    font-size: 0.9rem;
    font-weight: 700;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
  }
  .testi-name { font-size: 0.87rem; font-weight: 600; color: var(--dark); }
  .testi-role { font-size: 0.78rem; color: var(--muted); }

  /* ===== BLOG / RECENT POSTS ===== */
  .posts-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1.5rem; }
  .post-card {
    border: 1px solid var(--border);
    border-radius: 10px;
    overflow: hidden;
    transition: box-shadow 0.2s;
  }
  .post-card:hover { box-shadow: 0 4px 20px rgba(0,0,0,0.08); }
  .post-img { aspect-ratio: 16/9; background: var(--light); display: flex; align-items: center; justify-content: center; border-bottom: 1px solid var(--border); }
  .post-body { padding: 1.25rem; }
  .post-cat { font-size: 0.68rem; text-transform: uppercase; letter-spacing: 0.12em; color: var(--primary); font-weight: 600; margin-bottom: 0.5rem; }
  .post-title { font-family: 'Barlow Condensed', sans-serif; font-size: 1.15rem; font-weight: 700; color: var(--dark); line-height: 1.3; margin-bottom: 0.6rem; }
  .post-excerpt { font-size: 0.83rem; color: var(--muted); line-height: 1.6; margin-bottom: 1rem; }
  .post-meta { font-size: 0.75rem; color: var(--muted); display: flex; gap: 1rem; }

  /* ===== CTA BANNER ===== */
  .cta-banner {
    background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);
    padding: 5rem 2rem;
    text-align: center;
  }
  .cta-inner { max-width: 640px; margin: 0 auto; }
  .cta-title { font-family: 'Barlow Condensed', sans-serif; font-size: 3rem; font-weight: 700; color: var(--white); margin-bottom: 1rem; }
  .cta-desc { font-size: 1rem; color: rgba(255,255,255,0.75); line-height: 1.65; margin-bottom: 2rem; }
  .cta-btns { display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; }

  /* ===== FOOTER ===== */
  footer { background: var(--dark); color: rgba(255,255,255,0.7); }
  .footer-top {
    max-width: 1200px;
    margin: 0 auto;
    padding: 4rem 2rem;
    display: grid;
    grid-template-columns: 2fr 1fr 1fr 1fr;
    gap: 3rem;
  }
  .footer-brand .site-logo { margin-bottom: 1rem; display: block; }
  .footer-desc { font-size: 0.87rem; line-height: 1.7; max-width: 260px; }
  .footer-col h4 { font-family: 'Barlow Condensed', sans-serif; font-size: 1rem; font-weight: 700; color: var(--white); text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 1.25rem; }
  .footer-col ul { list-style: none; display: flex; flex-direction: column; gap: 0.65rem; }
  .footer-col ul li a { font-size: 0.85rem; color: rgba(255,255,255,0.6); transition: color 0.2s; }
  .footer-col ul li a:hover { color: var(--accent); }
  .footer-bottom {
    border-top: 1px solid rgba(255,255,255,0.1);
    padding: 1.5rem 2rem;
    max-width: 1200px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 0.8rem;
    color: rgba(255,255,255,0.4);
  }

  /* ===== BREADCRUMB (WP style) ===== */
  .breadcrumb-bar {
    background: var(--light);
    border-bottom: 1px solid var(--border);
    padding: 0.6rem 2rem;
    font-size: 0.8rem;
    color: var(--muted);
  }
  .breadcrumb-inner { max-width: 1200px; margin: 0 auto; }
  .breadcrumb-inner a { color: var(--primary); }
  .breadcrumb-inner a:hover { text-decoration: underline; }

  /* ===== SIDEBAR LAYOUT (for inner pages) ===== */
  .page-layout { max-width: 1200px; margin: 0 auto; padding: 3rem 2rem; display: grid; grid-template-columns: 1fr 300px; gap: 3rem; }
  .sidebar-widget { margin-bottom: 2rem; }
  .widget-title { font-family: 'Barlow Condensed', sans-serif; font-size: 1.1rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: var(--dark); padding-bottom: 0.6rem; border-bottom: 3px solid var(--primary); margin-bottom: 1rem; }
  .widget-list { list-style: none; }
  .widget-list li { padding: 0.5rem 0; border-bottom: 1px solid var(--border); font-size: 0.85rem; }
  .widget-list li a { color: var(--mid); transition: color 0.2s; }
  .widget-list li a:hover { color: var(--primary); }
  .widget-search { display: flex; gap: 0; }
  .widget-search input {
    flex: 1;
    padding: 0.6rem 0.9rem;
    border: 1px solid var(--border);
    border-right: none;
    border-radius: 4px 0 0 4px;
    font-size: 0.85rem;
    font-family: 'Barlow', sans-serif;
    color: var(--text);
    outline: none;
  }
  .widget-search button {
    background: var(--primary);
    color: white;
    border: none;
    padding: 0.6rem 1rem;
    border-radius: 0 4px 4px 0;
    font-family: 'Barlow Condensed', sans-serif;
    font-weight: 700;
    font-size: 0.85rem;
    cursor: pointer;
    text-transform: uppercase;
  }

  /* SVG icon helpers */
  .icon { width: 40px; height: 40px; flex-shrink: 0; }
</style>
</head>
<body>

<!-- WP ADMIN BAR -->
<div class="wp-admin-bar">
  <span class="wp-logo">⚡ WordPress</span>
  <span>+ New</span>
  <span>Edit Page</span>
  <span>Customize</span>
  <span style="margin-left: auto;">Howdy, Admin</span>
</div>

<!-- HEADER -->
<header>
  <div class="header-inner">
    <a href="https://geartrakr.com/" class="site-logo">GEAR<span>TRAKR</span></a>
    <nav class="main-nav">
      <a href="https://geartrakr.com/" class="active">Home</a>
      <a href="https://geartrakr.com/tutorial/">Tutorial</a>
      <a href="https://geartrakr.com/#shop">Shop</a>
      <a href="https://geartrakr.com/#how-it-works">How It Works</a>
      <a href="https://geartrakr.com/#about">About</a>
    </nav>
    <a href="https://geartrakr.com/#shop" class="header-cta">Get Tags</a>
  </div>
</header>

<!-- BREADCRUMB -->
<div class="breadcrumb-bar">
  <div class="breadcrumb-inner">
    <a href="https://geartrakr.com/">Home</a> &rsaquo; Lost &amp; Found Tags
  </div>
</div>

<!-- HERO -->
<section class="hero">
  <div class="hero-grid">
    <div class="hero-left">
      <div class="hero-badge">
        <span>●</span> NFC Powered · No GPS Required
      </div>
      <h1 class="hero-title">
        Never Lose Your<br>
        <span class="highlight">Gear Again</span>
      </h1>
      <p class="hero-desc">Smart NFC tags and stickers for backpacks, golf clubs, instruments, jackets, and more. When found, anyone can scan and return it — instantly.</p>
      <div class="hero-btns">
        <a href="https://geartrakr.com/#shop" class="btn-yellow">Shop Tags</a>
        <a href="https://geartrakr.com/tutorial/" class="btn-ghost">View Tutorial</a>
      </div>
    </div>
    <div class="hero-visual">
      <div class="tag-card">
        <div class="tag-card-label">📡 Gear Trakr Tag Found</div>
        <div class="tag-card-name">John Smith's Backpack</div>
        <div class="tag-card-info">📞 (555) 867-5309 · ✉ john@email.com</div>
      </div>
      <div class="tag-scan-btn">
        <div class="scan-dot"></div>
        Ready to scan NFC tag…
      </div>
      <div class="tag-card" style="background:rgba(244,166,20,0.08); border-color:rgba(244,166,20,0.3);">
        <div class="tag-card-label" style="color:rgba(255,255,255,0.5);">✅ Owner Notified</div>
        <div class="tag-card-name" style="font-size:1rem; font-weight:400; color:rgba(255,255,255,0.7);">A notification was sent to the tag owner.</div>
      </div>
    </div>
  </div>
</section>

<!-- TRUST BAR -->
<div class="trust-bar">
  <div class="trust-inner">
    <div class="trust-item">
      <svg class="trust-icon" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="9" stroke="white" stroke-width="1.5"/><path d="M6 10l3 3 5-5" stroke="white" stroke-width="1.5" stroke-linecap="round"/></svg>
      Safe for Kids &amp; Adults
    </div>
    <div class="trust-item">
      <svg class="trust-icon" viewBox="0 0 20 20" fill="none"><rect x="3" y="3" width="14" height="14" rx="2" stroke="white" stroke-width="1.5"/><path d="M7 10h6M10 7v6" stroke="white" stroke-width="1.5"/></svg>
      No GPS or Bluetooth
    </div>
    <div class="trust-item">
      <svg class="trust-icon" viewBox="0 0 20 20" fill="none"><path d="M10 2l2 6h6l-5 4 2 6-5-4-5 4 2-6L2 8h6z" stroke="white" stroke-width="1.5"/></svg>
      Works with Any Smartphone
    </div>
    <div class="trust-item">
      <svg class="trust-icon" viewBox="0 0 20 20" fill="none"><path d="M10 17s-7-5-7-10a7 7 0 0114 0c0 5-7 10-7 10z" stroke="white" stroke-width="1.5"/></svg>
      Schools &amp; Golf Courses Partner
    </div>
    <div class="trust-item">
      <svg class="trust-icon" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="9" stroke="white" stroke-width="1.5"/><path d="M10 6v4l3 3" stroke="white" stroke-width="1.5" stroke-linecap="round"/></svg>
      Instant Owner Notification
    </div>
  </div>
</div>

<!-- HOW IT WORKS -->
<section class="section" id="how-it-works">
  <div class="section-inner">
    <div class="section-header">
      <p class="section-label">Simple Process</p>
      <h2 class="section-title">How Gear Trakr Works</h2>
      <p class="section-desc">Three easy steps to protect your belongings with NFC technology.</p>
    </div>
    <div class="steps-grid">
      <div class="step-card">
        <div class="step-num">01</div>
        <svg class="step-icon icon" viewBox="0 0 40 40" fill="none"><rect x="8" y="6" width="24" height="28" rx="3" stroke="#0A6EBD" stroke-width="1.8"/><path d="M14 14h12M14 19h8M14 24h10" stroke="#0A6EBD" stroke-width="1.5" stroke-linecap="round"/></svg>
        <h3 class="step-title">Create a Tag</h3>
        <p class="step-desc">Download the app and enter your contact info. Save your record and write it to an NFC tag in seconds.</p>
        <a href="https://geartrakr.com/tutorial/" class="step-link">See Tutorial →</a>
      </div>
      <div class="step-card">
        <div class="step-num">02</div>
        <svg class="step-icon icon" viewBox="0 0 40 40" fill="none"><path d="M20 8C13.4 8 8 13.4 8 20s5.4 12 12 12 12-5.4 12-12S26.6 8 20 8z" stroke="#0A6EBD" stroke-width="1.8"/><path d="M20 14v6l4 4" stroke="#0A6EBD" stroke-width="1.8" stroke-linecap="round"/></svg>
        <h3 class="step-title">Attach to Gear</h3>
        <p class="step-desc">Stick your tag or sticker to any item — backpack, golf club, jacket, instrument, or keys.</p>
        <a href="https://geartrakr.com/tutorial/" class="step-link">See Tutorial →</a>
      </div>
      <div class="step-card">
        <div class="step-num">03</div>
        <svg class="step-icon icon" viewBox="0 0 40 40" fill="none"><path d="M10 32l8-8M22 18l6-6M14 22l4-4" stroke="#0A6EBD" stroke-width="1.8" stroke-linecap="round"/><circle cx="28" cy="14" r="5" stroke="#F4A614" stroke-width="1.8"/></svg>
        <h3 class="step-title">Get It Back</h3>
        <p class="step-desc">When found, anyone scans the tag. Your info is displayed and you get a notification immediately.</p>
        <a href="https://geartrakr.com/tutorial/" class="step-link">See Tutorial →</a>
      </div>
    </div>
  </div>
</section>

<!-- SHOP -->
<section class="section bg-light" id="shop">
  <div class="section-inner">
    <div class="section-header">
      <p class="section-label">Our Products</p>
      <h2 class="section-title">Tags &amp; Sticker Packs</h2>
      <p class="section-desc">Affordable name tags and NFC stickers for every type of gear your family owns.</p>
    </div>
    <div class="products-grid">
      <div class="product-card">
        <div class="product-img">
          <svg width="64" height="64" viewBox="0 0 64 64" fill="none" opacity="0.25"><rect x="16" y="16" width="32" height="32" rx="6" stroke="#0A6EBD" stroke-width="2"/><circle cx="32" cy="32" r="8" stroke="#0A6EBD" stroke-width="2"/></svg>
        </div>
        <div class="product-body">
          <p class="product-cat">NFC Tag</p>
          <h3 class="product-name">Starter Tag Pack</h3>
          <p class="product-desc">4 NFC tags with attachment accessories. Perfect for backpacks, jackets, and keys.</p>
          <div class="product-price">$14.99 <span>/ 4-pack</span></div>
          <a href="https://geartrakr.com/#shop" class="btn-buy">Add to Cart</a>
        </div>
      </div>
      <div class="product-card">
        <div class="product-img">
          <svg width="64" height="64" viewBox="0 0 64 64" fill="none" opacity="0.25"><rect x="10" y="22" width="44" height="20" rx="4" stroke="#0A6EBD" stroke-width="2"/><path d="M24 22v-4a8 8 0 0116 0v4" stroke="#0A6EBD" stroke-width="2"/></svg>
        </div>
        <div class="product-body">
          <p class="product-cat">Family Bundle</p>
          <h3 class="product-name">Family Pack</h3>
          <p class="product-desc">12 NFC tags + 6 adhesive sticker labels. Great for school bags, sports gear, and instruments.</p>
          <div class="product-price">$29.99 <span>/ 12-pack</span></div>
          <a href="https://geartrakr.com/#shop" class="btn-buy">Add to Cart</a>
        </div>
      </div>
      <div class="product-card">
        <div class="product-img">
          <svg width="64" height="64" viewBox="0 0 64 64" fill="none" opacity="0.25"><path d="M32 10l5 15h15L40 35l5 15-13-9-13 9 5-15L12 25h15z" stroke="#F4A614" stroke-width="2"/></svg>
        </div>
        <div class="product-body">
          <p class="product-cat">Organization Pack</p>
          <h3 class="product-name">School &amp; Golf Bundle</h3>
          <p class="product-desc">Bulk NFC tags for schools and golf courses. Partner pricing available. Contact us for details.</p>
          <div class="product-price">Custom <span>/ bulk pricing</span></div>
          <a href="https://geartrakr.com/#about" class="btn-buy" style="background:#F4A614; color:#0D1B2A;">Contact Us</a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- TUTORIAL SECTION -->
<section class="section" id="tutorial">
  <div class="section-inner">
    <div class="tutorial-grid">
      <div>
        <p class="section-label">Step-by-Step Guide</p>
        <h2 class="section-title" style="text-align:left; margin-bottom:1.5rem;">App Tutorial</h2>
        <div class="tutorial-steps">
          <div class="tut-step">
            <div class="tut-num">1</div>
            <div class="tut-content">
              <h4>Download the App</h4>
              <p>Available on iOS and Android. Open and create your account to get started.</p>
            </div>
          </div>
          <div class="tut-step">
            <div class="tut-num">2</div>
            <div class="tut-content">
              <h4>Write to Tag</h4>
              <p>Enter your name, phone, and email. Tap "Write Tag" and hold your phone to the NFC tag to save your info.</p>
            </div>
          </div>
          <div class="tut-step">
            <div class="tut-num">3</div>
            <div class="tut-content">
              <h4>Read a Found Tag</h4>
              <p>Open app, choose "Read." Hold phone to tag. The owner's info displays — call, message, or email to return.</p>
            </div>
          </div>
          <div class="tut-step">
            <div class="tut-num">4</div>
            <div class="tut-content">
              <h4>Erase a Tag</h4>
              <p>Use the "Erase" option in the main menu to clear all data from a tag before reusing.</p>
            </div>
          </div>
        </div>
        <div class="tutorial-cta" style="text-align:left; margin-top:2rem;">
          <a href="https://geartrakr.com/tutorial/">Full Tutorial Guide →</a>
        </div>
      </div>
      <div class="tutorial-visual">
        <div class="phone-mock">
          <div class="phone-header">📱 Gear Trakr App</div>
          <div class="phone-field">
            <div class="phone-field-label">Name</div>
            <div class="phone-field-val">Sarah Johnson</div>
          </div>
          <div class="phone-field">
            <div class="phone-field-label">Phone</div>
            <div class="phone-field-val">(555) 234-5678</div>
          </div>
          <div class="phone-field">
            <div class="phone-field-label">Email</div>
            <div class="phone-field-val">sarah@email.com</div>
          </div>
        </div>
        <div class="phone-scan-area">
          📡 Hold phone near NFC tag<br>
          <span style="font-size:0.75rem; color:rgba(255,255,255,0.4);">iPhone: top-back · Android: middle-back</span>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section class="section bg-light">
  <div class="section-inner">
    <div class="section-header">
      <p class="section-label">Happy Customers</p>
      <h2 class="section-title">What Families Are Saying</h2>
    </div>
    <div class="testimonials-grid">
      <div class="testi-card">
        <div class="stars">★★★★★</div>
        <p class="testi-text">"My son loses everything. Since getting Gear Trakr tags for his backpack and jacket, we've had three items returned already. Total game changer for our family."</p>
        <div class="testi-author">
          <div class="testi-avatar">MK</div>
          <div>
            <div class="testi-name">Michelle K.</div>
            <div class="testi-role">Parent · Ohio</div>
          </div>
        </div>
      </div>
      <div class="testi-card">
        <div class="stars">★★★★★</div>
        <p class="testi-text">"We use these at our golf course pro shop. So much easier than the old lost and found. Golfers get their clubs back same day now."</p>
        <div class="testi-author">
          <div class="testi-avatar">DL</div>
          <div>
            <div class="testi-name">Dave L.</div>
            <div class="testi-role">Golf Course Manager</div>
          </div>
        </div>
      </div>
      <div class="testi-card">
        <div class="stars">★★★★★</div>
        <p class="testi-text">"Our school adopted Gear Trakr last semester and the lost and found pile shrank by 80%. Parents love that they get notified when items are found."</p>
        <div class="testi-author">
          <div class="testi-avatar">PT</div>
          <div>
            <div class="testi-name">Principal Tran</div>
            <div class="testi-role">Elementary School · CA</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- RECENT POSTS -->
<section class="section">
  <div class="section-inner">
    <div class="section-header">
      <p class="section-label">News &amp; Tips</p>
      <h2 class="section-title">Latest from the Blog</h2>
    </div>
    <div class="posts-grid">
      <a href="https://geartrakr.com/tutorial/" class="post-card">
        <div class="post-img">
          <svg width="48" height="48" viewBox="0 0 48 48" fill="none" opacity="0.2"><rect x="10" y="8" width="28" height="32" rx="3" stroke="#0A6EBD" stroke-width="2"/><path d="M16 18h16M16 24h10" stroke="#0A6EBD" stroke-width="2"/></svg>
        </div>
        <div class="post-body">
          <p class="post-cat">Tutorial</p>
          <h3 class="post-title">Getting Started with Your NFC Tag</h3>
          <p class="post-excerpt">A complete walkthrough from unboxing to your first scan. Everything you need to protect your gear.</p>
          <div class="post-meta"><span>Apr 4, 2024</span><span>5 min read</span></div>
        </div>
      </a>
      <a href="https://geartrakr.com/" class="post-card">
        <div class="post-img">
          <svg width="48" height="48" viewBox="0 0 48 48" fill="none" opacity="0.2"><circle cx="24" cy="24" r="18" stroke="#0A6EBD" stroke-width="2"/><path d="M16 24h16M24 16v16" stroke="#0A6EBD" stroke-width="2"/></svg>
        </div>
        <div class="post-body">
          <p class="post-cat">Tips</p>
          <h3 class="post-title">Back to School: Tag Every Item Your Child Owns</h3>
          <p class="post-excerpt">School season is here. Here's the ultimate checklist for tagging backpacks, jackets, boots, and more.</p>
          <div class="post-meta"><span>Aug 15, 2024</span><span>4 min read</span></div>
        </div>
      </a>
      <a href="https://geartrakr.com/" class="post-card">
        <div class="post-img">
          <svg width="48" height="48" viewBox="0 0 48 48" fill="none" opacity="0.2"><path d="M24 8l5 14h14l-11 8 4 14-12-9-12 9 4-14L6 22h14z" stroke="#F4A614" stroke-width="2"/></svg>
        </div>
        <div class="post-body">
          <p class="post-cat">Partners</p>
          <h3 class="post-title">How Golf Courses Are Eliminating Lost &amp; Found</h3>
          <p class="post-excerpt">Our partner program helps clubs and courses return gear instantly. Learn how to bring Gear Trakr to your organization.</p>
          <div class="post-meta"><span>Jan 30, 2024</span><span>6 min read</span></div>
        </div>
      </a>
    </div>
  </div>
</section>

<!-- CTA BANNER -->
<section class="cta-banner">
  <div class="cta-inner">
    <h2 class="cta-title">Ready to Protect Your Gear?</h2>
    <p class="cta-desc">Join thousands of families, schools, and golf courses who trust Gear Trakr to bring their belongings home.</p>
    <div class="cta-btns">
      <a href="https://geartrakr.com/#shop" class="btn-yellow">Shop Now</a>
      <a href="https://geartrakr.com/tutorial/" class="btn-ghost">View Tutorial</a>
    </div>
  </div>
</section>

<!-- FOOTER -->
<footer>
  <div class="footer-top">
    <div class="footer-brand">
      <a href="https://geartrakr.com/" class="site-logo">GEAR<span style="color:var(--accent)">TRAKR</span></a>
      <p class="footer-desc">Rooted in family, designed to protect, and meant for ease of mind. NFC tags that bring your lost gear back home.</p>
    </div>
    <div class="footer-col">
      <h4>Products</h4>
      <ul>
        <li><a href="https://geartrakr.com/#shop">NFC Tags</a></li>
        <li><a href="https://geartrakr.com/#shop">Sticker Labels</a></li>
        <li><a href="https://geartrakr.com/#shop">Family Pack</a></li>
        <li><a href="https://geartrakr.com/#shop">Bulk / Partners</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h4>Help</h4>
      <ul>
        <li><a href="https://geartrakr.com/tutorial/">Tutorial</a></li>
        <li><a href="https://geartrakr.com/tutorial/">App Guide</a></li>
        <li><a href="https://geartrakr.com/#how-it-works">How It Works</a></li>
        <li><a href="https://geartrakr.com/#about">Contact</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h4>Company</h4>
      <ul>
        <li><a href="https://geartrakr.com/#about">About Us</a></li>
        <li><a href="https://geartrakr.com/">Partners</a></li>
        <li><a href="https://geartrakr.com/">Privacy Policy</a></li>
        <li><a href="https://geartrakr.com/">Terms of Use</a></li>
      </ul>
    </div>
  </div>
  <div class="footer-bottom">
    <span>© 2026 Gear Trakr. All rights reserved.</span>
    <span>Powered by WordPress</span>
  </div>
</footer>

</body>
</html>